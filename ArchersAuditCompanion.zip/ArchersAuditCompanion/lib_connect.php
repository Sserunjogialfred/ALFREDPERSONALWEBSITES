<?php

error_reporting(4);
@session_start();
//$_SESSION['home_url']="http://localhost/2023/AAIMS";
require_once('conf.php');
$_SESSION['dbconn'] = mysqli_connect(DB_SERVER, DB_USER, DB_PWD, DB_NAME) or die('ERROR:' . mysqli_connect_error());

function formatData($data) {
  $data = trim($data);
  $data = addslashes($data);
  $data = str_replace("'","",$data);
  $data = htmlspecialchars($data);
  $data = strtolower($data);
  return ucwords($data);
}

function RetrieveformattedData($data) {
  $data = trim($data);
  $data = addslashes($data);
  $data = str_replace("'","",$data);
  $data = htmlspecialchars($data);
  $data = strtolower($data);
  return ucwords($data);
}

function http($line){
$data="Http Error code $line because,".mysqli_error($_SESSION['dbconn']) ;
$subject="Runtime Error/Warning Recieved "; //By ".$_SESSION['username']."
$message=$data." on " .$_SERVER['SCRIPT_NAME'];
return $data;
}

//Query information from the database
    function Execute($query)
    {
        return $x = @mysqli_query($_SESSION['dbconn'], $query);
          }

	function FetchRecords($query){
		return $x=@mysqli_fetch_array($query);
	}
	

?>