<?php

if(!defined("DB_TYPE"))
	define("DB_TYPE","mysql");

if(!defined("DB_SERVER"))
	define("DB_SERVER","localhost");

if(!defined("DB_USER"))
	define("DB_USER","root");

if(!defined("DB_PWD"))
	define("DB_PWD","");

if(!defined("DB_NAME"))
	define("DB_NAME","AAM");
		
if(!defined("DB_PORT"))
	define("DB_PORT","3306");


define("COOKIE_EXPIRE", 60*60*24*100);  //100 days by default
define("COOKIE_PATH", "/");  //Avaible in whole domain


//function to connect to database		
	function connect(){
		$conn = mysqli_connect(DB_SERVER, DB_USER, DB_PWD, DB_NAME) or die('ERROR:' . mysqli_connect_error());
		//$db = mysql_select_db(DB_NAME,$conn);		 
		if($conn){
			return TRUE;
		} else{
			throw new Exception("Database Connection Failure");
		}
	}
		

	function secureInput($var)
	{
			
		$output = '';
		if (is_array($var)){
			foreach($var as $key=>$val){
				$output[$key] = secureInput($val);
			}
		} else {
			$var = strip_tags(trim($var));
			if (function_exists("get_magic_quotes_gpc")) {
				$output = mysqli_escape_string(get_magic_quotes_gpc() ? stripslashes($var) : $var);
			} else {
				$output = mysqli_escape_string($var);
			}
		}
		if (!empty($output))
		return $output;
	}
	


?>
