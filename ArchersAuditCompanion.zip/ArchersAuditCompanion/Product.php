<?php
require_once('lib_connect.php');
//require_once('ItemClass.php');
require_once('xajax_0.5/xajax_core/xajax.inc.php');

$xajax = new xajax();
$xajax->setFlag('debug',false);

#***************************************************
//     Registered Methods/  Functions
#***************************************************
$xajax->register(XAJAX_FUNCTION,'gaRegister');
$xajax->register(XAJAX_FUNCTION,'saveGaRegister');
$xajax->register(XAJAX_FUNCTION,'viewRegister');
$xajax->register(XAJAX_FUNCTION,'editRegister');
$xajax->register(XAJAX_FUNCTION,'updateRegister');
$xajax->register(XAJAX_FUNCTION,'deleteRegister');
$xajax->register(XAJAX_FUNCTION,'viewDetails');

/*===================================*/
//  View registered Expenses
/*===================================*/
function viewRegister($Product_Name){
$obj = new  xajaxResponse();
//$ObjReg = new Register('');

$data="<form name='notification' id='notification'  action='exporttoexcel.php' method='post' onsubmit=\"$('#datatodisplay').val( $('<div>').append( $('#export').eq(0).clone() ).html() )\">";
$data.="  
<div class='table-responsive'>
  <table class='table justify-content-center'' width='60%'>";
$data.="<tr><td>
  <div class='card bg-brown text-white'>
    <div class='card-body'> 
      <div class='top-bar'>
        <div class='bdy-header'>
          <h3><b>ARCHERS AUDIT COMPANION SYSTEM</b></h3>  
        </div>
    </div>
     
    </div>
  </div>";
$data.="</td></tr>";

 $data.="<tr><td>
<!-------------Another Table for results section-->
  <div class='card bg-light text-dark'>
  <div class='card-header'>
    <h4><strong> Manage Products & Services </strong></h4>
    <div class='row'>
      <div class='col'></div>
      <div class='col'>
        <input type='text' class='form-control'  onBlur=\"xajax_viewRegister(getElementById('name').value);return false;\" id='name' placeholder='Enter content to Search' name='name' id='name' >
      </div>

      <div class='col'>
        <input type='button' onClick=\"xajax_viewRegister(getElementById('name').value);return false;\" class='btn btn-secondary' name='search' value='Go'> 
        <input type='submit' class='btn btn-success' value='Excel'>
        <input type='hidden' id='datatodisplay' name='datatodisplay'> | <input type='button' class='btn btn-primary' name='search' value='Register' onclick=\"xajax_gaRegister();return false;\"></div>
      </div>
  </div>
</div></div>



    <div class='card-body'> 
    <!--//----------search fields go here-->
    
   
  
    
    <!--//------end of search fields------>
  <div class='form-group'>
    <!-------------Another Table for results section-->";
    $data.="<table id='export' class='table table-striped'>
    <thead>
      <tr>
      <th>#</th>
        <th>Product Name</th>
        <th>Product Description</th>
        <th class='col_hd'>Category</th>
        <th class='col_hd'>Currency</th>
        <th class='col_hd'>Product Costs</th>
        <th class='col_hd' colspan='3'>Action Buttons</th>
      </tr>
    </thead>
    <tbody>";
    $n=1;
    $sql=" SELECT * from tbl_products";
    $query=Execute($sql) or die(httpt("viewRegister_0089"));
      while ($row = FetchRecords($query)){
 extract($row);
$data.= "<tr>";
$data.= "<td>".$n."</td>";
$data.= "<td>".htmlspecialchars(strip_tags($Product_Name))."</td>";
$data.= "<td>".htmlspecialchars(strip_tags($Description))."</td>";
$data.= "<td>".htmlspecialchars(strip_tags($category))."</td>";
$data.= "<td class='row_data'>".htmlspecialchars(strip_tags($currency))."</td>";
$data.= "<td class='row_data'>".htmlspecialchars(strip_tags($Price))."</td>";

		
$data.="<td>
  <i class='fa fa-eye btn btn-secondary' aria-hidden='false title='View Record''  onClick=\"xajax_viewDetails('".$id."');\">
<br>View</i>
</td> ";
          
$data.="<td>
  <i class='fa fa-edit btn btn-primary' title='Edit Record'  onClick=\"xajax_editRegister('".$id."');\"><br>Edit</i>
</td>";

$data.="<td>
  <i class='fa fa-trash-o fa-lg btn btn-warning' title='delete Record'  onclick=\"xajax_deleteRegister('".$id."')\" >
<br>Delete</i>
</td>";
						
$data.= "</tr>";
  $n++;
  }
  $data.="</tbody>
  </table>";
    $data.="<!-------------End of table Another Table for results section-->
  </div>
  </div>
  <!----second card details----->
  </td></tr>";   
$data.="</table>
</div></form>";  
$obj->assign('bodyDisplay','innerHTML',$data);
return $obj;
}


/*===================================*/
//      edit registered Expenses
/*===================================*/
function editRegister($id){
$obj = new  xajaxResponse();
//$objReg = new Register('');
$data="<form name='notification' id='notification' action='#' method='post'>";
$data.="  
<div class='table-responsive'>
  <table class='table justify-content-center'' width='60%'>";
  $data.="<tr><td>
    <div class='card bg-brown text-white'>
      <div class='card-body'> 
        <div class='top-bar'>
          <div class='bdy-header'>
              <h3><b>ARCHERS AUDIT COMPANION SYSTEM</b></h3>  
          </div>
        </div>
      </div>
    </div>
  <div class='card bg-light text-dark'>
    <div class='card-body'><h4>Modify Product Details</h4></div>
  </div>
 
  </td></tr>";
    $x="select * from tbl_products where id='".$id."'";
    $query=@Execute($x) or die(http("editRegister-158"));
    while($row=FetchRecords($query)){
        extract($row);
    $data.="<tr><td>";
    $data.="<div class='form-group'>
    <label for='name'>Product Name:</label>
    <input type='text' class='form-control' id='Product_Name'  name='Product_Name' value='".$Product_Name."' required>
	  <div class='valid-feedback'>Valid.</div>
    <div class='invalid-feedback'>Please fill out this field.</div>
    </div>";

    $data.="<div class='form-group'>
    <label for='name'>Product Description:</label>
    <input type='text' class='form-control' id='Description'  name='Description' value='".$Description."' required>
	  <div class='valid-feedback'>Valid.</div>
    <div class='invalid-feedback'>Please fill out this field.</div>
    </div>";

  $data.="<div class='form-group'>
    <label for='category'>Category:</label>
    <input type='text' class='form-control' id='category'  name='category' value='".$category."' required>
	  <div class='valid-feedback'>Valid.</div>
    <div class='invalid-feedback'>Please fill out this field.</div>
  </div>";

  $data.="<div class='form-group'>
    <label for='category'>Currency:</label>
    <input type='text' class='form-control' id='currency'  name='currency' value='".$currency."' required>
	  <div class='valid-feedback'>Valid.</div>
    <div class='invalid-feedback'>Please fill out this field.</div>
  </div>";

  $data.="<div class='form-group'>
    <label for='category'>Amount Paid:</label>
    <input type='text' class='form-control' id='Amount_paid'  name='Amount_paid' value='".$Price."' required>
	  <div class='valid-feedback'>Valid.</div>
    <div class='invalid-feedback'>Please fill out this field.</div>
  </div>";

  $data.="<a href='Product.php''>
    <button type='Button' class='btn btn-secondary'>Back</button></a>
    <button type='Button'  onclick=\"xajax_updateRegister(xajax.getFormValues('notification'),'".$id."');return false;\" class='btn btn-primary'>Update</button>
 </td></tr>";
  }
  $data.=" 
 
  </table></form>";
    $obj->assign('bodyDisplay','innerHTML',$data);
    return $obj; 
  }

    
/*===================================*/
//  Updates a registered Expense Details
/*===================================*/
function updateRegister($formvalues,$id){
$obj = new  xajaxResponse();
    //$ObjReg = new Register('');
    $Product_Name=htmlspecialchars(strip_tags($formvalues['Product_Name']));
    $Description=htmlspecialchars(strip_tags($formvalues['Description']));
    $category=htmlspecialchars(strip_tags($formvalues['category']));
    $currency=htmlspecialchars(strip_tags($formvalues['currency']));
    $Price=htmlspecialchars(strip_tags($formvalues['Price']));
    $x="UPDATE tbl_products set Product_Name='".$Product_Name."', Description='".$Description."', category='".$category."',currency='".$currency."',Price='".$Price."' where id='".$id."'";
    $query=@Execute($x) or die(http("upadateRegister-222"));

    //-----------show update message
    if($query){
      $obj->alert("Data Updated Sucessfully!");  
    }
    
  return $obj;  
}

/*===================================*/
//    Register new Account Details
/*===================================*/
function gaRegister(){
$obj = new  xajaxResponse();
//$obj = new Register('');
$sql = "INSERT INTO tbl_products (`Product_Name`,`Description`,`category`) VALUE('".$Product_Name."','".$Description."','".$category."')";
//$sql = $stmt->saveRecord('$name, $email, $age');
$query=@Execute($sql) or die(http("Register_record-263"));
$data="<form name='notification' id='notification'  action='?' onSubmit method='post'>";
$data.="<div class='card bg-brown text-white'>
  <div class='card-body'> 
    <div class='top-bar'>
      <div class='bdy-header'>
        <h3><b>ARCHERS AUDIT COMPANION SYSTEM</b></h3>  
      </div>  
    </div>
  </div>
  <div class='card bg-light text-dark'>
    <div class='card-body'><h4>Add new Product Details</h4></div>
  </div>
</div>";
$data.=" <div class='table-responsive'>
  <table class='table justify-content-center'' width='80%'>";
$data.="<tr><td>";

$data."</td></tr>
<tr><td><!-- Green -->
<div class='progress'>
  <div class='progress-bar bg-success' style='width:40%'>40%</div>
  <h3></h3>
</div></td></tr>";
   
$data.="<tr>
  <td><!----second card details----->
  <div class='card bg-light text-dark'>
  <div class='card-body'>

  <div class='form-group'>
    <label for='Product Name'>Product Name:</label>
    <input type='text' class='form-control' id='Product_Name' placeholder='Enter Product Name' name='Product_Name' required>
    <div class='valid-feedback'>Valid.</div>
    <div class='invalid-feedback'>Please fill out this field.</div>
  </div>

  <div class='form-group'>
    <label for='Product Description'>Product Description:</label>
    <input type='text' class='form-control' id='Description' placeholder='Enter Product Description' name='Description' required>
    <div class='valid-feedback'>Valid.</div>
    <div class='invalid-feedback'>Please fill out this field.</div>
  </div>

  <div class='form-group'>
    <label for='Category Name'>Category:</label>
    <input type='text' class='form-control' id='category' placeholder='Enter category' name='category' required>
    <div class='valid-feedback'>Valid.</div>
    <div class='invalid-feedback'>Please fill out this field.</div>
  </div>";

  
  $data.="</td></tr>";
    $data.="<tr><td><div class='card bg-light text-dark'>
  <div class='card-body'>";
  
  
  $data.="<a href='Product.php'>
    <button type='Button' class='btn btn-secondary'>Back</button></strong></a>
    <input type='Button' class='btn btn-danger' onclick=\"xajax_gaRegister();return false;\" value='Clear'/>
    <input type='Button' onclick=\"xajax_saveGaRegister(xajax.getFormValues('notification'));return false;\" class='btn btn-primary' value='Save' />
  </td></tr>";

  

  $data.="<tr><td><div class='card bg-alert'>
    <div class='card-body' id='Process_alert'>
    </div>
  </div></td></tr>";   
  $data.="</table>
</div></form>";
$obj->assign('bodyDisplay','innerHTML',$data);
return $obj;
}

/*===================================*/
//  Saves new Account Records 
/*===================================*/
function saveGaRegister($formvalues){
$obj=new xajaxResponse();
//$stmt = new Register('');
$Description=$formvalues['Product_Name'];
$Description=$formvalues['Description'];
$category=$formvalues['category'];
$sql="INSERT INTO tbl_products (`Product_Name`,`Description`, `category`) 
VALUES ('".$Product_Name."','".$Description."','".$category."')";

if($Description==''){
$obj->alert("Product Description Missing!");
return $obj;
}
if($Product_Name==''){
$obj->alert("Product Name Missing!");
return $obj;
}
if($category==''){
$obj->alert("Record category Missing!");
return $obj;
}

$query=@Execute($sql)or die(http("SaveProducts-Details_0346"));
if($query){
$obj->assign('Process_alert','innerHTML',"New record Saved Successfully!");
return $obj;
}
$obj->alert("Error:Saving new record Failed!, Please re-try");
return $obj;
}

/*===================================*/
//  View all Record  Details
/*===================================*/
function viewDetails($id){
$obj = new  xajaxResponse();
//$objReg = new Register('');
$data="<form name='notification' id='notification' action='#' method='post'>";
$data.="<div class='table-responsive'>
<table class='table justify-content-center'' width='60%'>";
$data.="<tr><td>
        <div class='card bg-brown text-white'>
          <div class='card-body'> 
            <div class='top-bar'>
              <div class='bdy-header'>
                <h3><b>ARCHERS AUDIT COMPANION SYSTEM</b></h3>  
              </div>  
            </div>
          </div>
        </div>";
      $data.="</td></tr>";
  $sql="select * from tbl_products where id='".$id."'";
  $query=@Execute($sql) or die(http("ViewProduct-Details-406"));
  while($row=FetchRecords($query)){
      extract($row);

  $data.="<tr><td>";
    $data.="<div class='card bg-lime text-dark'>
      <div class='card-title'><h2><b>Archers Products & Services</b></h2>
    <div>";

    $data.="<div class='row'>
      <div class='col'><label for='name'><strong>Product Name:</strong></label></div>
    <div class='col'>".$Product_Name."</div></div>";

     $data.="<div class='row'>
      <div class='col'><label for='name'><strong>Product Description:</strong></label></div>
    <div class='col'>".$Description."</div></div>";


    $data.="<div class='row'>
      <div class='col'><label for='name'><strong>Category:</strong></label></div>
    <div class='col'><b>".$category."</b></div></div>";

    $data.="<div class='row'>
      <div class='col'><label for='name'><strong>Amount Paid:</strong></label></div>
    <div class='col'>".$currency.": <b>".$Price."</b></div></div>";

  $data.="<div class='row'>
    <div class='col'><label for='name'><strong><button type='Button' class='btn btn-secondary' onclick=\"xajax_viewRegister('');return false;\">Back</button></strong></label></div>
  <div class='col'></div></div>";   

  $data.="</div></div>

  </td></tr>";
  }
$data.=" 

</table></form>";
  $obj->assign('bodyDisplay','innerHTML',$data);
  return $obj; 
}

/*===================================*/
//       Delete Record Details
/*===================================*/
function deleteRegister($id){
$obj=new xajaxResponse();
$sql="DELETE FROM tbl_products WHERE id='".$id."'";
$query=@Execute($sql)or die(http("Delete-Record_431"));
if($query){
$obj->assign('bodyDisplay',"innerHTML","Record-Detail deleted, Successfully!");
}
    $obj->redirect('Product.php');
  return $obj;  
}

#************************************
$xajax->processRequest();

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>AACS || Invoices</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php $xajax->printJavascript('xajax_0.5/'); ?>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.3/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
  <!-- FONT-OWESOME -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- FAVICON -->
 <link href="./images/Archers-Car-Branding-copy-10-1.png" rel="icon" type="image">
  <!-- CSS Scripts -->
  <link rel="stylesheet" href="style.css" >
  
<style>
p#demo {
  text-align: center;
  font-size: 32px;
  margin-top: 0px;
    font-weight: bolder;
    font-style: normal;
    transform-origin: left;
    
}
</style>
    <script>
// Set the date we're counting down to
var countDownDate = new Date("May 17, 2023 08:00:00").getTime();

// Update the count down every 1 second
var x = setInterval(function() {

  // Get today's date and time
  var now = new Date().getTime();
    
  // Find the distance between now and the count down date
  var distance = countDownDate - now;
    
  // Time calculations for days, hours, minutes and seconds
  var days = Math.floor(distance / (1000 * 60 * 60 * 24));
  var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
  var seconds = Math.floor((distance % (1000 * 60)) / 1000);
    
  // Output the result in an element with id="demo"
  document.getElementById("demo").innerHTML = days + " Days " + hours + " Hrs "
  + minutes + " m " + seconds + " s ";
    
  // If the count down is over, write some text 
  if (distance < 0) {
    clearInterval(x);
    document.getElementById("demo").innerHTML = "EXPIRED";
  }
}, 1000);
</script>
    
</head>
<!-- End Header -->
<!---Google Translate reference-->
 <script type="text/javascript">
function googleTranslateElementInit() {
  new google.translate.TranslateElement({pageLanguage: 'en', layout: google.translate.TranslateElement.InlineLayout.SIMPLE,includedLanguages: "ar,en,fr,sw,rw,lg,lg,ln,rw,ach"}, 'google_translate_element');
}
</script> 

 <script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script> 
 <!---Google Translate reference-->

<body>

<nav class="navbar navbar-expand-sm bg-light fixed-top" id="nav-background">
  <a class="navbar-brand" href="Product.php"><img src="./images/Archers-Car-Branding-copy-10-1.png" class="logoo" ></a>
  <ul class="navbar-nav">
    <li class="nav-item">
      <a class="nav-link" href="Product.php?linkvar=Register"><strong><i class="fa fa-tachometer" aria-hidden="true"></i>&nbsp;Dashboard</strong></a>
    </li>

    <div class="nav-item dropdown">
      <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown"><strong><i class="fa fa-file fa-fw" aria-hidden="true"></i>&nbsp;Invoices</strong></a>
      <div class="dropdown-menu">
        <a href="Product.php" class="dropdown-item"><i class="fa-thin fa-file-invoice"></i>&nbsp;Proforma Invoices</a>
        <a href="invoices.php" class="dropdown-item">Commercial Invoices</a>
      </div>
    </div>

    <div class="nav-item dropdown">
      <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown"><strong><i class="fa fa-address-book fa-fw" aria-hidden="true"></i>&nbsp;Financial Records</strong></a>
      <div class="dropdown-menu">
        <a href="Income.php" class="dropdown-item"><i class="fa fa-receipt fa-fw"></i>Company Income</a>
        <a href="Expenses.php" class="dropdown-item">Company Expenses</a>
      </div>
    </div>

    <div class="nav-item dropdown">
      <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown"><strong><i class="fa fa-book fa-fw" aria-hidden="true"></i>&nbsp;Office Records</strong></a>
      <div class="dropdown-menu">
        <a href="#" class="dropdown-item"><i class="fa fa-receipt fa-fw"></i>Reciepts</a>
        <a href="#" class="dropdown-item">Monthly Reports</a>
        <a href="#" class="dropdown-item">Accountabilities</a>
      </div>
    </div>
    
    <li class="nav-item">
      <a class="nav-link" id="google_translate_element" ></a>
    </li>

    <li class="nav-item">
        <a class="nav-link" id="logout" href='logout.php' onClick="return confirm('Are sure want to logout?, Confirm to Proceed.....')"><strong><i class="fa fa-sign-out" aria-hidden="true"></i>&nbsp;Logout</strong></a>
      </li>

  </ul>
</nav>
 
<div class="container-fluid" style="margin-top:80px" id="bodyDisplay" >
                                
    <script language="JavaScript" type="text/javascript">

	xajax_viewRegister('');
	
	
</script>
</div>

<?php //require_once("connections/footer.php"); ?>
</body>
</html>