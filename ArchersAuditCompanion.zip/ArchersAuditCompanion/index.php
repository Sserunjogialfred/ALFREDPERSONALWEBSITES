<!DOCTYPE html>
 <html lang="en"> 
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <!-- TITLE -->
  <title>|| AACS || USER LOGIN</title>
  <!-- CSS STYLING -->
  <link rel="stylesheet" href="login.css">
  <!-- FONT-OWESOME -->
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css">
  <!-- FAVICON -->
  <link href="./images/Archers-Car-Branding-copy-10-1.png" rel="icon" type="image">
</head>
<body>
  <div class="login">
    <h1>USER LOGIN</h1>
    <form method="post" action="login.php">
     
      <p><i class="fa fa-user" aria-hidden="true" style='font-size:36px;color:#c06e0a;margin-left:5px;padding:10px;'></i><input type="text" name="uname" value="" placeholder="Username"></p>
      <p><i class="fas fa-lock" aria-hidden="true" style='font-size:36px;color:#c06e0a;margin-left:5px;padding:10px;' ></i><input type="password" name="pword" value="" placeholder="Password"></p>
      <p class="remember_me">
        <label>
          <input type="checkbox" name="remember_me" id="remember_me">
          Remember me 
        </label>
      </p>
      <p class="submit"><input type="submit" name="commit" value="Login"></p>
    </form>
  </div>

</body>
</html>
